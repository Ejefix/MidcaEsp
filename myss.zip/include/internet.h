#ifndef INTERNET_H
#define INTERNET_H
#include <WiFi.h>
#include <Arduino.h>
#include "encryption.h"
#include <skeleton.h>
#include <config.h>
#include <clock.h>
#include <WebServer.h>
#include "SyncBuilder.h"
#include "authorization.h"
#include "myWIFI.h"

class Internet : public Encryption, public Config
{
public:
  explicit Internet(CLOCK &myclock);
  void start();
  bool connect();
  void startTCPSerwer();
  void processServerResponse();

private:
  // void ping_pong();

  void communication_udp();

  // Порт TCP сервера
  const uint16_t TCP_PORT = 9000;

  // TCP сервер
  WiFiServer *tcpServer{nullptr};
  

  WiFiUDP Udp;
  const uint16_t portUDT{1001};
  NetworkManager serwer;

  // std::deque<ClientTCP *> clients;

  const String local_name = "MIDCAMAINU";
  MyWiFi wifi{};
};

#endif
